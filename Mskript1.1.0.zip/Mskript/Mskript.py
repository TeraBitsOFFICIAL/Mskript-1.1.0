from turtle import *
import random
import time

print("start Mskript")
time.sleep(1)
print("loading.")
time.sleep(0.5)
print("loading..")
time.sleep(0.5)
print("loading...")
time.sleep(0.5)
ram1 = "150mb"
rom1 = "100mb"
print("RAM:" + ram1)
print("ROM:" + rom1)
time.sleep(1)
print("*########################################*")
print("")
print("               Mskript")
print("              BETA 1.1")
print("                help")
print("")
print("*########################################*")
while True:
    command1 = input("Enter command: ")
    if command1 == "help":
        print("*########################################*")
        print("                 Mskript")
        print("                BETA 1.1")
        print("")
        print("                Команды: ")
        print("               calculator")
        print("                 secret comment")
        print("                 help")
        print("                 login")
        print("                 exit")
        print("*########################################*")
    if command1 == "calculator":
        print("*########################################*")
        print("               Калькулятор")
        print("                 Версия 1")
        print("*########################################*")
        calc1 = float(input("1-число: "))
        calc2 = float(input("2-число: "))
        calc3 = input("+ -  * /: ")
        if calc3 == "+":
            answer1 = (calc1 + calc2)
            print(str(answer1))
            print("Решено")
        if calc3 == "-":
            answer1 = (calc1 - calc2)
            print(str(answer1))
            print("Решено")
        if calc3 == "*":
            answer1 = (calc1 * calc2)
            print(str(answer1))
            print("Решено")
        if calc3 == "/":
            answer1 = (calc1 / calc2)
            print(str(answer1))
            print("Решено")
    if command1 == "hacking the Pentagon":
        print("*########################################*")
        print("               Взлом пентогона")
        print("                Версия 1.0.0")
        print("            by TeraGitsCorporation")
        print("              TOP SECRET команда")
        print("*########################################*")
        log1 = input("пароль: ")
        if log1 == "vbnm1945cds":
            print("Запущен процесс взлома пентагона...")
            time.sleep(2)
            for i in range(1, 10):
                print("Взлом пентагона. Процесс - {}%".format(i*10))
                time.sleep(2)
            print("Пентагон успешно ВЗЛОМАН!")
            speed(10)
            color('cyan')
            bgcolor('black')
            b = 200

            while b > 0:
                left(b)
                forward(b * 3)
                b = b - 1
            exit()
    if command1 == "login":
        print("Имя пользоватиля")
        name = input()
        print('Привет,', name)
    if command1 == "exit":
        exit()
    if command1 == "Matrica":
        while True:
            print(random.randint(0, 9), end='')
    if command1 == "secret comment":
        comment1 = input("Ведите код: ")
        if comment1 == "beta1.0":
            print("*########################################*")
            print("      Mskript_BETA 1.0 2024.10.02")
            print("   Данная бета является засекреченой")
            print("  потому-что в ней нелья нечего сделать")
            print("          и она очень сырая")
            print("     сейчас мы роботаем на Mskript 2")
            print("      но это другой комментарий...")
            print("*########################################*")
        if comment1 == "MegOS1":
            print("*#############################################################*")
            print("                     MEGOS 1 beta 1.0")
            print("        ОС сделаня на пайтен и библеотеке Mskript")
            print("      Она представляла из себя операционную систему")
            print("     с минималистичным дизайном но проэкт проволился")
            print("     всё что должно было присутствовать в beta версий")
            print("   есть в Mskript больше команд можно узнать в команде")
            print("")
            print("                      TOP SECRET 1")
            print("*############################################################*")
        if comment1 == "TOP SECRET 1":
            print("*############################################################*")
            print("                     Секретные команды 1")
            print("                   hacking the Pentagon")
            print("                   TOP SECRET PASSWORD 1")
            print("                          Matrica")
            print("Скоро...")
            print("*############################################################*")
        if comment1 == "TOP SECRET PASSWORD 1":
            print("*############################################################*")
            print("                       Секретный пароли 1")
            print("                          vbnm1945cds")
            print("Скоро...")
            print("*############################################################*")
